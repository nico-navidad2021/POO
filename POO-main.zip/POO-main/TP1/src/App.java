import poo.ejercicios.uva1.ejercicio1.Ala;
import poo.ejercicios.uva1.ejercicio1.SistemaDeControlDeVuelo;
import poo.ejercicios.uva1.ejercicio3.MotorDeAvion;

public class App {
    public static void main(String[] args) throws Exception {

        //ALA
        Ala ala1 = new Ala( (float) 22.21, "Rojo", "Alumninio",1);
        Ala ala2 = new Ala((float) 25.2, "Amarillo", "Aleacion de niquel",2);
        
        System.out.println("INFORMACION CONTROL DE VUELO");
        System.out.println("");

        ala1.getEstadoGeneral();

        System.out.println("----------------------------");

        ala2.getEstadoGeneral();

        System.out.println("");
        System.out.println("Activo flap del ala1...");
        ala1.activarFlap();
        System.out.println("Activo flap del ala2...");
        ala2.activarFlap();

        System.out.println("");

        ala1.getEstadoGeneral();

        System.out.println("----------------------------");

        ala2.getEstadoGeneral();

        //CONTROL DE VUELO
        SistemaDeControlDeVuelo modo1 = new SistemaDeControlDeVuelo("AeroData", 2, "Automatico");
        SistemaDeControlDeVuelo modo2 = new SistemaDeControlDeVuelo("Avidyne", 3, "Manual");
        MotorDeAvion motorDeAvion1 = new MotorDeAvion("Embraer", 400, 300000);
     	MotorDeAvion motorDeAvion2 = new MotorDeAvion("Bombardier", 500, 500000);
        
     	System.out.println("");
        System.out.println("INFORMACION CONTROL DE VUELO");
        System.out.println("");
        modo1.getEstadoGeneral();
        motorDeAvion1.getCaracteristicasDelMotor();
        System.out.println("----------------------------");
        modo2.getEstadoGeneral();
        motorDeAvion2.getCaracteristicasDelMotor();
        System.out.println("");

        modo1.setModoVuelo(1);
        
        modo2.setModoVuelo(0);

        modo1.getEstadoGeneral();
        motorDeAvion1.arrancar();
        motorDeAvion1.detener();
        System.out.println("----------------------------");
        modo2.getEstadoGeneral();
        motorDeAvion2.setEstadoDelMotor(false);
        motorDeAvion2.arrancar();
        motorDeAvion2.detener();
        

    }
}
