package poo.ejercicios.uva1.ejercicio3;

public class MotorDeAvion {
	String marca;
	Integer caballosDeFuerza;
	Integer empuje;
	Boolean estadoDelMotor;

public MotorDeAvion(String marca, int caballosDeFuerza, int empuje) {
	this.marca = marca;
	this.caballosDeFuerza = caballosDeFuerza;
	this.empuje = empuje;
	this.estadoDelMotor = true;

}



public String getMarca(){
	return marca;
}

public int getCaballosDeFuerza(){
	return caballosDeFuerza;
}

public int getEmpuje(){
	return empuje;
}

public boolean getEstadoDelMotor(){
	return estadoDelMotor;
}

public void setEstadoDelMotor(boolean estadoDelMotor) {
	this.estadoDelMotor = estadoDelMotor;
}

public void setMarca(String marca){
	this.marca = marca;
}

public void setCaballosDeFuerza(int caballosDeFuerza){
	this.caballosDeFuerza = caballosDeFuerza;
}

public void setEmpuje(int empuje){
	this.empuje = empuje;
}


public void arrancar() {
	if(estadoDelMotor != true) {
		estadoDelMotor = true;
		System.out.println("El motor arrancó, se encuentra encendido");
	}
	else {
		System.out.println("El motor ya se encontraba encendido");	
	}
}


public void detener(){
	if(estadoDelMotor != false) {
		estadoDelMotor = false;
		System.out.println("El motor se detuvo, se encuentra apagado");
	}
	else {
		System.out.println("El motor ya se encontraba apagado");
	}

	}

public void getCaracteristicasDelMotor() {
	System.out.println("Marca: " + getMarca());
	System.out.println("Caballos De Fuerza: " + getCaballosDeFuerza() + "HP");
	System.out.println("Empuje: " + getEmpuje() + "LB");
}
}
