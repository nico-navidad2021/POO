import java.io.*;
import java.nio.file.AccessDeniedException;


public class App {
    public static void main(String[] args) throws Exception {
        String archivoInput = "src\\data.txt";
        String archivoOutput = "src\\resultado.txt";

        try (BufferedReader br_Reader = new BufferedReader(new FileReader(archivoInput));
            BufferedWriter br_Writer = new BufferedWriter(new FileWriter(archivoOutput))
        ) {


            procesarLinea(br_Reader, br_Writer);
            }

        catch (FileNotFoundException e) {
            System.out.println("El archivos ["+archivoInput+"] no fue encontrado. ("+e+")");
            //Catch para casos donde no se encuentre el archivo de lectura
        }
        catch(AccessDeniedException e){
            System.out.println("No fue posible acceder al archivo ["+archivoInput+"] o generar el archivos de salida en el directoriono fue encontrado. ("+e+")");
            //Catch para casos donde haya conflicto de permisos de lectura, escritura o creacion de archivos
        }
        catch(IOException e){
            System.out.println("Ha ocurrido un error al querer manejar el archivo de entrada o de salida. ("+e+")");
            //Catch para casos relacionados con IO y que no esten contemplados en los catch anteriores
        }
        catch(Exception e){
            System.out.println("Ha ocurrido un error durante la ejecucion del script. ("+e+")");
            //Catch generico para todo el resto de excepciones
        }

        /*limpiarArchivo(archivoOutput)*/;
    }

    public static void procesarLinea(BufferedReader br_Reader, BufferedWriter br_Writer) {
        try {
            BufferedReader br_Console = new BufferedReader(new InputStreamReader(System.in));

            System.out.print("¿Desea transcribir todo el contenido? (si/no): ");
            String respuesta = br_Console.readLine().trim().toLowerCase();

            if (respuesta.equals("si")) {
                String lineaLeida;
                while ((lineaLeida = br_Reader.readLine()) != null) {
                    br_Writer.write(lineaLeida);
                    br_Writer.newLine();
                }
                System.out.println("Se ha transcrito todo el contenido.");
            } else if (respuesta.equals("no")) {
                System.out.print("¿Cuántas líneas desea transcribir? ");
                int numLineas = Integer.parseInt(br_Console.readLine());

                String lineaLeida;
                int contador = 0;
                while ((lineaLeida = br_Reader.readLine()) != null && contador < numLineas) {
                    br_Writer.write(lineaLeida);
                    br_Writer.newLine();
                    contador++;
                }
                System.out.println("Se han transcrito " + contador + " líneas.");
            } else {
                System.out.println("Respuesta no válida. Por favor, responda 'sí' o 'no'.");
            }

        } catch (IOException e) {
            System.out.println("Error durante el procesamiento de líneas. (" + e + ")");
        } catch (NumberFormatException e) {
            System.out.println("Por favor, ingrese un número válido. (" + e + ")");
        }
    }
}
    /*public static void limpiarArchivo(String archivoOutput) {

        try (BufferedWriter br_Writer = new BufferedWriter(new FileWriter(archivoOutput, false))) {

            System.out.println("El archivo [" + archivoOutput + "] ha sido limpiado.");
        } catch (IOException e) {
            System.out.println("Error al limpiar el archivo [" + archivoOutput + "]. (" + e + ")");
        }*/



